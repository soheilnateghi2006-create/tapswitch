package com.example.quickswitch

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings tile: shows or hides the floating button in one tap. */
class ToggleTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        update()
    }

    override fun onClick() {
        super.onClick()
        val prefs = Prefs.of(this)
        prefs.edit().putBoolean(Prefs.ENABLED, !prefs.getBoolean(Prefs.ENABLED, true)).apply()
        update()
    }

    private fun update() {
        val tile = qsTile ?: return
        val on = Prefs.of(this).getBoolean(Prefs.ENABLED, true)
        tile.label = "TapSwitch"
        tile.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.updateTile()
    }
}
