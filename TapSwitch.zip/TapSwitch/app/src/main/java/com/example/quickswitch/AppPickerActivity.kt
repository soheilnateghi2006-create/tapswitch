package com.example.quickswitch

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/** Lets the user tick the apps in which the floating button should appear. */
class AppPickerActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs.of(this)
        val pm = packageManager

        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcherIntent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }

        val selected: MutableSet<String> =
            HashSet(prefs.getStringSet(Prefs.ALLOWED, emptySet()) ?: emptySet<String>())

        val list = ListView(this)
        list.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        list.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_multiple_choice,
            apps.map { it.second }
        )
        apps.forEachIndexed { i, a -> list.setItemChecked(i, selected.contains(a.first)) }
        list.setOnItemClickListener { _, _, pos, _ ->
            val pkg = apps[pos].first
            if (list.isItemChecked(pos)) selected.add(pkg) else selected.remove(pkg)
            prefs.edit().putStringSet(Prefs.ALLOWED, HashSet(selected)).apply()
        }

        val header = TextView(this).apply {
            text = tr("Show the button only in these apps", "دکمه فقط در این برنامه‌ها نمایش داده شود")
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(48, 96, 48, 32)
        }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(header)
        root.addView(list, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }
}
