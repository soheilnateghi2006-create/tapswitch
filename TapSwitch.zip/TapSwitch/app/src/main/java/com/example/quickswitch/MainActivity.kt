package com.example.quickswitch

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.Toast
import android.widget.TextView

/** Settings screen. Every change is saved at once and applied live by the service. */
class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var preview: ButtonView
    private lateinit var statusText: TextView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs.of(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(32))
        }

        col.addView(TextView(this).apply {
            text = "TapSwitch"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
        })

        preview = ButtonView(this)
        col.addView(preview)

        // ---- Status
        section(col, tr("Status", "وضعیت"))
        statusText = TextView(this).apply { textSize = 16f }
        col.addView(statusText)
        col.addView(Button(this).apply {
            text = tr("Open Accessibility settings", "باز کردن تنظیمات دسترسی‌پذیری")
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        col.addView(note(tr(
            "On Samsung: if the switch is greyed out, go to Settings > Apps > TapSwitch > ⋮ > Allow restricted settings, then set Battery to Unrestricted.",
            "سامسونگ: اگر سوییچ خاکستری بود، به تنظیمات > برنامه‌ها > TapSwitch > ⋮ > Allow restricted settings برو و باتری را روی Unrestricted بگذار."
        )))

        // ---- Control
        section(col, tr("Control", "کنترل"))
        toggle(col, tr("Show floating button", "نمایش دکمه‌ی شناور"), Prefs.ENABLED, true)
        col.addView(Button(this).apply {
            text = tr("Turn off completely", "خاموش کردن کامل")
            setOnClickListener {
                val s = SwitchService.instance
                if (s != null) {
                    s.disableSelf()
                    Toast.makeText(this@MainActivity, tr("Turned off", "خاموش شد"), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MainActivity, tr("Already off", "از قبل خاموش است"), Toast.LENGTH_SHORT).show()
                }
                postDelayed({ updateStatus() }, 600)
            }
        })
        col.addView(note(tr(
            "Tip: add the TapSwitch tile to your quick settings panel (swipe down, tap ✎ / +) to show or hide the button in one tap. To turn it back on after \"Turn off completely\", enable it again in Accessibility.",
            "نکته: کاشی TapSwitch را به پنل تنظیمات سریع اضافه کن (صفحه را به پایین بکش و ✎ یا + را بزن) تا با یک لمس دکمه را نشان بدهی یا پنهان کنی. بعد از «خاموش کردن کامل»، برای روشن کردن دوباره باید از Accessibility فعالش کنی."
        )))

        // ---- Appearance
        section(col, tr("Appearance", "ظاهر"))
        spinner(col, tr("Style", "سبک"), Prefs.STYLE,
            listOf(tr("iPhone style", "سبک آیفون"), tr("Circle", "دایره"), tr("Rounded square", "مربع گرد")), 0)
        col.addView(note(tr("Color (center of the iPhone style, or the whole button)", "رنگ (مرکز سبک آیفون یا کل دکمه)")))
        colorRow(col)
        slider(col, tr("Size", "اندازه"), Prefs.SIZE, 36, 80, 52, "dp")
        slider(col, tr("Opacity when active", "شفافیت حالت فعال"), Prefs.ACTIVE_ALPHA, 30, 100, 65, "%")
        slider(col, tr("Opacity when idle", "شفافیت حالت بی‌حرکت"), Prefs.IDLE_ALPHA, 5, 60, 20, "%")
        slider(col, tr("Fade after", "کم‌رنگ شدن بعد از"), Prefs.IDLE_DELAY, 1, 10, 3, tr("s", "ثانیه"))

        // ---- Behavior
        section(col, tr("Behavior", "رفتار"))
        slider(col, tr("Switch delay", "تأخیر سوییچ"), Prefs.DELAY, 80, 500, 150, "ms")
        toggle(col, tr("Vibrate on tap", "لرزش هنگام لمس"), Prefs.HAPTIC, true)
        spinner(col, tr("Vibration strength", "قدرت لرزش"), Prefs.HAPTIC_STRENGTH,
            listOf(tr("Light", "کم"), tr("Medium", "متوسط"), tr("Strong", "زیاد")), 1)
        toggle(col, tr("Snap to screen edge", "چسبیدن به لبه‌ی صفحه"), Prefs.SNAP, true)
        toggle(col, tr("Peek at edge (partly hidden)", "نیمه‌پنهان در لبه"), Prefs.PEEK, false)
        spinner(col, tr("Long press", "لمس طولانی"), Prefs.LONG_PRESS,
            listOf(
                tr("Hide for 30 seconds", "پنهان شدن برای ۳۰ ثانیه"),
                tr("Hide until next screen on", "پنهان تا روشن شدن بعدی صفحه"),
                tr("Do nothing", "هیچ کاری نکن"),
                tr("Turn off completely", "خاموش کردن کامل")
            ), 0)

        // ---- Apps
        section(col, tr("Apps", "برنامه‌ها"))
        toggle(col, tr("Show only in selected apps", "فقط در برنامه‌های انتخابی نمایش بده"), Prefs.ONLY_SELECTED, false)
        col.addView(Button(this).apply {
            text = tr("Choose apps", "انتخاب برنامه‌ها")
            setOnClickListener { startActivity(Intent(this@MainActivity, AppPickerActivity::class.java)) }
        })

        // ---- Advanced
        section(col, tr("Advanced", "پیشرفته"))
        col.addView(Button(this).apply {
            text = tr("Reset to defaults", "بازگشت به پیش‌فرض")
            setOnClickListener {
                prefs.edit().clear().apply()
                recreate()
            }
        })

        setContentView(ScrollView(this).apply { addView(col) })
        updatePreview()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val on = SwitchService.instance != null || isServiceEnabled()
        statusText.text = if (on) tr("Service is ON ✔", "سرویس روشن است ✔")
        else tr("Service is OFF. Enable TapSwitch in Accessibility.", "سرویس خاموش است. TapSwitch را در Accessibility روشن کن.")
        statusText.setTextColor(if (on) Color.parseColor("#2E7D32") else Color.parseColor("#C62828"))
    }

    private fun isServiceEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.contains("$packageName/") && s.contains("SwitchService")
    }

    // ---------------------------------------------------------------- UI helpers

    private fun section(col: LinearLayout, text: String) {
        col.addView(TextView(this).apply {
            this.text = text
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#1E88E5"))
            setPadding(0, dp(24), 0, dp(4))
        })
    }

    private fun note(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.GRAY)
        setPadding(0, dp(8), 0, dp(4))
    }

    private fun slider(col: LinearLayout, label: String, key: String, lo: Int, hi: Int, def: Int, unit: String) {
        val cur = prefs.getInt(key, def).coerceIn(lo, hi)
        val tv = TextView(this).apply {
            text = "$label: $cur $unit"
            setPadding(0, dp(10), 0, 0)
        }
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = cur - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + lo
                tv.text = "$label: $v $unit"
                if (fromUser) {
                    prefs.edit().putInt(key, v).apply()
                    updatePreview()
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        col.addView(tv)
        col.addView(sb)
    }

    private fun toggle(col: LinearLayout, label: String, key: String, def: Boolean) {
        val sw = Switch(this)
        sw.text = label
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setPadding(0, dp(8), 0, dp(8))
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
            updatePreview()
        }
        col.addView(sw)
    }

    private fun spinner(col: LinearLayout, label: String, key: String, items: List<String>, def: Int) {
        col.addView(TextView(this).apply {
            text = label
            setPadding(0, dp(10), 0, 0)
        })
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        sp.setSelection(prefs.getInt(key, def).coerceIn(0, items.size - 1))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != prefs.getInt(key, def)) {
                    prefs.edit().putInt(key, pos).apply()
                    updatePreview()
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        col.addView(sp)
    }

    private fun colorRow(col: LinearLayout) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val swatches = ArrayList<View>()

        fun refreshSwatches() {
            val sel = prefs.getInt(Prefs.COLOR, Color.WHITE)
            for ((i, sv) in swatches.withIndex()) {
                val c = Prefs.COLORS[i]
                val bg = GradientDrawable()
                bg.shape = GradientDrawable.OVAL
                bg.setColor(c)
                bg.setStroke(
                    dp(if (c == sel) 3 else 1),
                    if (c == sel) Color.parseColor("#1E88E5") else Color.GRAY
                )
                sv.background = bg
            }
        }

        for (c in Prefs.COLORS) {
            val sv = View(this)
            val lp = LinearLayout.LayoutParams(dp(36), dp(36))
            lp.setMargins(0, 0, dp(10), 0)
            sv.layoutParams = lp
            sv.setOnClickListener {
                prefs.edit().putInt(Prefs.COLOR, c).apply()
                refreshSwatches()
                updatePreview()
            }
            swatches.add(sv)
            row.addView(sv)
        }
        refreshSwatches()
        val hs = HorizontalScrollView(this)
        hs.addView(row)
        col.addView(hs)
    }

    private fun updatePreview() {
        val size = dp(prefs.getInt(Prefs.SIZE, 52))
        val lp = LinearLayout.LayoutParams(size, size)
        lp.gravity = Gravity.CENTER_HORIZONTAL
        lp.setMargins(0, dp(12), 0, dp(12))
        preview.layoutParams = lp
        preview.style = prefs.getInt(Prefs.STYLE, 0)
        preview.accent = prefs.getInt(Prefs.COLOR, Color.WHITE)
        preview.alpha = prefs.getInt(Prefs.ACTIVE_ALPHA, 65) / 100f
    }
}
